from django.contrib import admin

# Register your models here.
from .models import Driver, Lorry, Costumer, Order

class DriverFilter(admin.ModelAdmin):
    search_fields = ('full_name', 'inn_num','phone')
    list_display = ('full_name', 'inn_num','phone')
    list_filter = ('full_name', 'inn_num','phone')
admin.site.register(Driver, DriverFilter)

class LorryFilter(admin.ModelAdmin):
    search_fields = ('number_lorry', 'number_seats', 'reserve_free')
    list_display = ('number_lorry', 'number_seats', 'reserve_free')
    list_filter = ('number_lorry', 'number_seats', 'reserve_free')
admin.site.register(Lorry, LorryFilter)

class CostumerFilter(admin.ModelAdmin):
    search_fields = ('full_name', 'passport', 'phone')
    list_display = ('full_name', 'passport', 'phone')
    list_filter = ('full_name', 'passport', 'phone')
admin.site.register(Costumer, CostumerFilter)

class OrderFilter(admin.ModelAdmin):
    search_fields = ('client', 'application_date', 'lorry', 'delivery_status', 'cost')
    list_display = ('client', 'application_date', 'lorry', 'delivery_status', 'cost')
    list_filter = ('client', 'application_date', 'lorry', 'delivery_status', 'cost')
admin.site.register(Order, OrderFilter)

