from django.db import models

# Create your models here.
class Driver(models.Model):
    full_name = models.CharField(verbose_name='ФИО', max_length=72, unique=False)
    date_birth = models.DateField(verbose_name='Дата рождения')
    expirience = models.PositiveIntegerField(verbose_name='Стаж вождения')
    inn_num = models.CharField(verbose_name='ИНН', max_length=12, unique=True, primary_key=True)
    phone = models.CharField(verbose_name='Номер телефона', max_length=13, unique=True)

    class Meta:
        verbose_name = u'Водитель'
        verbose_name_plural = u'Водители'

    def __unicode__(self):
        return self.name

    def __str__(self):
        return '%s' % (self.full_name)


class Lorry(models.Model):
    number_lorry = models.CharField(verbose_name='Регистрационный номер', max_length=9, unique=True, primary_key=True)
    driver = models.ForeignKey(Driver, on_delete=models.CASCADE, verbose_name='ФИО водителя')
    number_seats = models.PositiveIntegerField(verbose_name='Количество мест')
    reserve_free = models.CharField(verbose_name='Статус машины', max_length=8)

    class Meta:
        verbose_name = u'Машина'
        verbose_name_plural = u'Машины'

    def __unicode__(self):
        return self.name

    def __str__(self):
        return '%s' % (self.number_lorry)


class Costumer(models.Model):
    full_name = models.CharField(verbose_name='ФИО', max_length=72, unique=False)
    passport = models.CharField(verbose_name='Серия и номер пасспорта', max_length=10, unique=True, primary_key=True)
    phone = models.CharField(verbose_name='Номер телефона', max_length=13, unique=True)

    class Meta:
        verbose_name = u'Клиент'
        verbose_name_plural = u'Клиенты'

    def __unicode__(self):
        return self.name

    def __str__(self):
        return '%s' % (self.full_name)


class Order(models.Model):
    client = models.ForeignKey(Costumer, on_delete=models.CASCADE, verbose_name='ФИО клиента')
    distance_km = models.PositiveIntegerField(verbose_name='Расстояние, км')
    lorry = models.ForeignKey(Lorry, on_delete=models.CASCADE, verbose_name='Номер машины')
    whence = models.CharField(verbose_name='Куда', max_length=72)
    whither = models.CharField(verbose_name='Откуда', max_length=72)
    application_date = models.DateField(verbose_name='Дата заявки', auto_now_add=True)
    delivery_status = models.CharField(verbose_name='Статус заявки', max_length=20)
    delivery_date = models.DateField(verbose_name='Дата доставки')
    number_seats = models.PositiveIntegerField(verbose_name='Количество мест')
    lift = models.PositiveIntegerField(verbose_name='Этаж')
    cost = models.PositiveIntegerField(verbose_name='Стоимость')

    class Meta:
        verbose_name = u'Заказ'
        verbose_name_plural = u'Заказы'

    def __unicode__(self):
          return self.name
